"""Offline fixture replay; not a general CMS adapter. Python 3, no dependencies."""
import json, hashlib, pathlib
from html.parser import HTMLParser

ROOT=pathlib.Path(__file__).resolve().parent
sha=lambda s: hashlib.sha256(s.encode('utf-8')).hexdigest()

class Document(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=True)
        self.nodes=[]; self.stack=[]
        self.feed(source)
    def handle_starttag(self,tag,attrs):
        n={'tag':tag,'attrs':dict(attrs),'text':''}; self.nodes.append(n)
        if tag not in {'meta','link','br','img','input','hr'}: self.stack.append(n)
    def handle_endtag(self,tag):
        if self.stack and self.stack[-1]['tag']==tag: self.stack.pop()
    def handle_data(self,data):
        for n in self.stack: n['text']+=data
    def select(self,selector):
        if selector=='body': return [n for n in self.nodes if n['tag']=='body']
        if selector.startswith('#'): return [n for n in self.nodes if n['attrs'].get('id')==selector[1:]]
        raise ValueError('Unsupported fixture selector: '+selector)

def replay(source,result,applied_ids=()):
    if result['status']!='ready': raise ValueError('Payload is not ready')
    if sha(source)!=result['evidence']['targetSnapshotHash']: raise ValueError('Snapshot mismatch')
    original=Document(source)
    ids=[c['id'] for c in result['changes']]
    if len(ids)!=len(set(ids)) or set(ids)&set(applied_ids): raise ValueError('Duplicate change ID')
    # Validate every precondition against the same original snapshot before any write.
    for c in result['changes']:
        if c['selector']!='body' or c['operation'] not in {'append_html','append_json_ld'}: raise ValueError('Unsupported operation')
        if c['precondition']['snapshotSha256']!=sha(source): raise ValueError('Precondition hash mismatch')
        if len(original.select(c['selector']))!=c['precondition']['selectorCount']: raise ValueError('Selector precondition failed')
    if source.count('</body>')!=1: raise ValueError('Fixture requires one literal closing body tag')
    fragments=[]
    for c in result['changes']:
        fragments.append(c['payload'] if c['operation']=='append_html' else '<script type="application/ld+json">'+json.dumps(c['payload'],separators=(',',':')).replace('<','\\u003c')+'</script>')
    after=source.replace('</body>',''.join(fragments)+'</body>')
    return after,ids

def check(source,test):
    d=Document(source)
    if test['type']=='selector_count': return len(d.select(test['selector']))==test['expected']
    if test['type']=='text_contains':
        nodes=d.select(test['selector'])
        return bool(nodes) and all(any(x in n['text'] for n in nodes) for x in test['expected'])
    if test['type']=='json_ld_webpage_url':
        for n in d.nodes:
            if n['tag']=='script' and n['attrs'].get('type')=='application/ld+json':
                obj=json.loads(n['text'])
                if obj.get('@type')=='WebPage' and obj.get('url')==test['expected']: return True
        return False
    raise ValueError('Unknown acceptance test')

def main():
    inp=json.loads((ROOT/'input.json').read_text()); result=json.loads((ROOT/'output.json').read_text())[0]
    before=(ROOT/'before.html').read_text()
    assert before==inp['targetHtml']
    assert sha(inp['competitorHtml'])==result['evidence']['competitorSnapshotHash']
    assert sha(inp['evidence']['answer'])==result['evidence']['answerHash']
    after,ids=replay(before,result)
    report={'targetSnapshotHashVerified':True,'competitorSnapshotHashVerified':True,'answerHashVerified':True,'inputHashCheck':'Not recomputed: Actor canonicalization algorithm is outside this consumer example','checks':[{'test':t,'before':check(before,t),'after':check(after,t)} for t in result['acceptanceTests']]}
    assert all(t['after'] for t in report['checks'])
    for name,source,seen in [('stale_snapshot',before+' ',()),('repeat_application',before,ids),('changed_page',after,())]:
        try: replay(source,result,seen)
        except ValueError as e: report[name]={'rejected':True,'reason':str(e)}
        else: raise AssertionError(name+' was not rejected')
    (ROOT/'after.html').write_text(after)
    (ROOT/'applied-change-ids.json').write_text(json.dumps(ids,indent=2)+'\n')
    (ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
