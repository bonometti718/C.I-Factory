"""Independently check the captured demo calculations; this is not the production core."""
from pathlib import Path
from decimal import Decimal, getcontext
import json
getcontext().prec=40
ROOT=Path(__file__).resolve().parent
D=lambda x:Decimal(str(x))
EXPECTED={'buy':'BUY','tie':'SKIP','expensive':'SKIP','escalate':'ESCALATE','stop':'STOP','better-alternative':'SKIP'}
checks=[]
for case in json.loads((ROOT/'cases.json').read_text()):
    i=case['input']; o=case['output']; v=D(i['task_value']); p0=D(i['baseline_success_probability']); p1=p0+D(i['action']['success_probability_delta'])
    baseline=p0*v; gross=p1*v; ev=gross-D(i['action']['cost'])
    options=[('BASELINE' if baseline>0 else 'STOP',baseline)]
    options += [(a['id'],D(a['success_probability'])*v-D(a['cost'])) for a in i['alternatives']]
    # Stable max preserves baseline/earlier substitute on equal value.
    outside_id,outside=max(options,key=lambda x:x[1])
    confidence=min([D(i.get('confidence',0))]+[D(a.get('confidence',i.get('confidence',0))) for a in i['alternatives']])
    if confidence<D('0.8'): decision,reason,rec='ESCALATE','INSUFFICIENT_ESTIMATE_CONFIDENCE',None
    elif ev>outside and ev>0: decision,reason,rec='BUY','ACTION_HAS_HIGHEST_POSITIVE_EXPECTED_VALUE',i['action']['id']
    elif max(ev,outside)<=0: decision,reason,rec='STOP','NO_POSITIVE_EXPECTED_VALUE','STOP'
    else: decision,reason,rec='SKIP',('NO_STRICT_ECONOMIC_ADVANTAGE' if ev==outside else 'BETTER_OUTSIDE_OPTION'),outside_id
    assert o['decision']==decision==EXPECTED[case['id']]
    assert o['recommended_option']==rec
    assert o['structured_reason']['code']==reason
    assert o['structured_reason']['best_outside_option']==outside_id
    assert D(o['structured_reason']['confidence'])==confidence
    assert D(o['structured_reason']['action_success_probability'])==p1
    values={'baseline_expected_value':baseline,'gross_action_value':gross,'expected_value':ev,'marginal_value':ev-baseline,'best_outside_expected_value':outside,'advantage_over_best_outside':ev-outside,'max_rational_price':max(D(0),gross-outside)}
    for key,value in values.items(): assert D(o[key])==value,(case['id'],key)
    assert o['break_even_attainable']==(gross-outside>=0)
    for alternative,result in zip(i['alternatives'],o['substitute_comparison'],strict=True):
        alt_ev=D(alternative['success_probability'])*v-D(alternative['cost'])
        assert D(result['expected_value'])==alt_ev
        assert D(result['advantage_over_action'])==alt_ev-ev
    checks.append({'case':case['id'],'decision':decision,'verified':True,'checks':'Decision, reason, recommendation, confidence, probabilities, seven economic values, break-even flag and substitute comparisons'})
invalid=json.loads((ROOT/'invalid-case.json').read_text())
assert D(invalid['input']['baseline_success_probability'])+D(invalid['input']['action']['success_probability_delta'])>1
assert invalid['observedError']['name']=='InputError'
assert invalid['observedError']['field']=='action.success_probability_delta'
report={'scope':'Offline verification of captured outputs from actual local core; not a marketplace request or real-world probability validation','cases':checks,'invalidProbabilityObservedRejection':True,'allPassed':True}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
